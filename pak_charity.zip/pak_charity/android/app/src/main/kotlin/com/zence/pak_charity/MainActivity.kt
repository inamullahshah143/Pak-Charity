package com.zence.pak_charity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
